package com.example.bmi;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.google.android.material.textfield.TextInputEditText;

public class MainActivity extends AppCompatActivity {
    TextView resulttv;
    Button btn_cal,btn_res;
    TextInputEditText tie1,tie2,tie3;
    MenuItem menuitem;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.options,menu);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.item) {
            Intent i = new Intent(MainActivity.this, About.class);
            startActivity(i);
        }
        return super.onOptionsItemSelected(item);
    }
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        menuitem = findViewById(R.id.item);
        resulttv = findViewById(R.id.result);
        btn_cal = findViewById(R.id.button_cal);
        btn_res = findViewById(R.id.button_res);
        tie1 = findViewById(R.id.tie_age);
        tie2 = findViewById(R.id.tie_weight);
        tie3= findViewById(R.id.tie_height);
    }

    public void button_cal(View view) {
        float wt = Float.parseFloat(tie2.getText().toString());
        int age =  Integer.parseInt(tie1.getText().toString());
        float ht =  Float.parseFloat(tie3.getText().toString());
        float h_t_m = ht/100;
        float bmi = wt/(h_t_m*h_t_m);
        if(bmi<16){
            resulttv.setText(bmi+"\nYou are Severely Underweight");
            resulttv.setTextColor(getResources().getColor(R.color.blue_1));
        } else if(bmi>16 && bmi<18.5){
            resulttv.setText(bmi+"\nYou are Underweight");
            resulttv.setTextColor(getResources().getColor(R.color.blue_2));
        } else if(bmi>18.5 && bmi<24.9){
            resulttv.setText(bmi+"\nYou are normal(healthy weight)");
            resulttv.setTextColor(getResources().getColor(R.color.green_1));
        } else if(bmi>25.0 && bmi<29.9){
            resulttv.setText(bmi+"\nYou are overweight");
            resulttv.setTextColor(getResources().getColor(R.color.yellow_1));
        } else if(bmi>30.0){
            resulttv.setText(bmi+"\nYou are obesity");
            resulttv.setTextColor(getResources().getColor(R.color.red_1));
        }
    }

    public void button_res(View view) {

        tie1.setText("");
        tie2.setText("");
        tie3.setText("");
        resulttv.setText("Result");
        resulttv.setTextColor(getResources().getColor(android.R.color.white));
    }
}
